_base_ = './llff_default_lg.py'

expname = 'orchids_lg'

data = dict(
    datadir='./data/nerf_llff_data/orchids',
)

