_base_ = './lf_default.py'

expname = 'dvgo_Statue_unbounded'

data = dict(
    datadir='./data/lf_data/statue',
)

