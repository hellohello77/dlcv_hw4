_base_ = './tt_default.py'

expname = 'dvgo_Playground_unbounded'

data = dict(
    datadir='./data/tanks_and_temples/tat_intermediate_Playground',
)

