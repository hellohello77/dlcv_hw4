_base_ = './llff_default_lg.py'

expname = 'horns_lg'

data = dict(
    datadir='./data/nerf_llff_data/horns',
)

