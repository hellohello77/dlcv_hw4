_base_ = '../default.py'

expname = './dvgo_hotdog'
basedir = './'

data = dict(
    datadir='./hotdog',
    dataset_type='blender',
    white_bkgd=True,
)

