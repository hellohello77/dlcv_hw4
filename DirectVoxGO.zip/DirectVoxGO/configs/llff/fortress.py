_base_ = './llff_default.py'

expname = 'fortress'

data = dict(
    datadir='./data/nerf_llff_data/fortress',
)

