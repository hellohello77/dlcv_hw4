_base_ = './llff_default_lg.py'

expname = 'room_lg'

data = dict(
    datadir='./data/nerf_llff_data/room',
)

