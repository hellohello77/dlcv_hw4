_base_ = './llff_default.py'

expname = 'horns'

data = dict(
    datadir='./data/nerf_llff_data/horns',
)

